This is a highly-modified TFMX-1.6 editor, with 7 voice and Pro format extensions (as well as NTSC bug fixes)
Fixed by marx marvellous.. what a cool guy ;)

set icon tooltypes or run from commandline with -h to see cli options.

it might crash on 040 systems. it normally works fine on my a1200/030
but still sometimes has crashes

i made a tiny change to the sourcecode to ignore the filesystem
on a drive. if you have problems with it use my modified version

if anyone wants to modify the code even more to make it 100% friendly then feel free.
the iff gui files can be modified also to make custom interfaces also :)

so... lets see some of you people make some cool 7channel tfmx mods..

marx did :)

/buzz
