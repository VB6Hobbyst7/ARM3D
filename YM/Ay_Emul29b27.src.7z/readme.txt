ZX Spectrum Sound Chip Emulator source code.

Program "AY-3-8910/12 Emulator"
Version 2.9 beta 27 for Windows and Linux
Author is Sergey Vladimirovich Bulba
(c)1999-2021 S.V.Bulba

Send any comments to Sergey Bulba <svbulba@gmail.com>
Ay_Emul home page is http://bulba.untergrund.net/

You can use this source code freely, only do references to author (Sergey Bulba).

Compilers used for corresponding versions:
Win32: Lazarus 2.0.12, FPC 3.2.0, x86_64-win64-win32/win64 (cross-i386-win32)
Win64: Lazarus 2.0.12, FPC 3.2.0, x86_64-win64-win32/win64
Lin32: Lazarus 2.0.12, FPC 3.2.0, i386-linux-gtk2
Lin64: Lazarus 2.0.12, FPC 3.2.0, x86_64-linux-gtk2
